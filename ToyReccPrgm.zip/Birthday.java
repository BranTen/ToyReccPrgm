/* Brandon Tennyson
 * CMSC 203
 * Assignment 2
 * 2/9/2017
 * Professor: DR. Robert Alexander
 * Description:
 * This program prompts the user to enter a name and age for a kid
 * and then lets the user choose from a variety of gifts for the kid
 * then the program will show the price and the receipt for each kid 
 * */

package assignment2;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;
//import java.util.Scanner;

public class Birthday {

	public static void main(String[] args) {
		//Scanner in = new Scanner(System.in);
		//initializations
		String name,toy, ageInput, YN, addCard,addBaloon, checkAge ;
		int age;
		double cost =0;
		Toy t;
		// do while loop for the program to repeat
		do { 

			// prompt user to enter name and age of kid
			name = JOptionPane.showInputDialog("name of kid");
			ageInput = JOptionPane.showInputDialog("how old its the kid");
			age = Integer.parseInt(ageInput);
			do{
			// display different toys for the kid
			toy = JOptionPane.showInputDialog("choose a toy: a plushie, blocks, or a book");
			while (!(toy.equalsIgnoreCase("plushie")||toy.equalsIgnoreCase("book") 
					|| toy.equalsIgnoreCase("Blocks")))// only if the chose a valid choice, let them continue
			{//try again 
				JOptionPane.showMessageDialog(null, "ERROR not valid, Try again");
				toy = JOptionPane.showInputDialog("choose a toy: a plushie, blocks, or a book");
			}
			t = new Toy(toy,age); // create new toy object
			if (t.ageOK()){ //ageok will return a boolean value 
				JOptionPane.showMessageDialog(null,"age is good!");
				checkAge = "no";
			}
			else // display if the user wants to continue with current toy even though its a bad age
				checkAge = JOptionPane.showInputDialog("the toy is not age appropriate"
						+ "\n cancel toy request? (Yes/No)");

				
			}while (checkAge.equalsIgnoreCase("yes"));
			
			
			// prompt user if they want to add a card or baloons for additional cost to their order
			addCard = JOptionPane.showInputDialog("do you want a card with your gift(Yes/No)");
			if (addCard.equalsIgnoreCase("yes")){
				t.addCard(addCard);
			}
			addBaloon = JOptionPane.showInputDialog("do you want to add a baloon with your gift? (Yes/No)");
			if (addBaloon.equalsIgnoreCase("yes")){
				t.addBalloon(addBaloon);
			}
			// display name and order
			JOptionPane.showMessageDialog(null,name + t.toString());
			// display on eclipse console
			System.out.println("the gift for " +name + t.toString());
			cost = t.getCost() + cost; // add up all of the costs to create a total
			YN = JOptionPane.showInputDialog("do you want to enter another toy? (Yes/No)");
			if (YN.equalsIgnoreCase("no")){ //if the user does not want to enter another toy show recipt
				System.out.println("the total cost for our order is $" + cost);
				System.out.println("\n\n your order number is " + new DecimalFormat("#####").format(Math.random()*100000));
				System.out.println("Programmer name: Brandon Tennyson");
			
			}
		}			while (YN.equalsIgnoreCase("yes"));
	}
}